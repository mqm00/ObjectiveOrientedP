package oosd.concreteclass;

public class MyFileSearch {
}