package oosd.concreteclass;

public class MySearchResult {

}